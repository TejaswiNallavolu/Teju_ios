//
//  ViewController.swift
//  Nallavolu_FormatName
//
//  Created by student on 9/6/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var submitbtn: UIButton!
    @IBOutlet weak var displayRsult: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Reset(_ sender: UIButton) {
        displayRsult.text = " "
        firstNameTF.text = " "
        lastNameTF.text = " "
    }
    
    @IBAction func submitPressed(_ sender: UIButton) {
        
        displayRsult.backgroundColor = .green
    
        
        displayRsult.text = "\(lastNameTF.text!),  \(firstNameTF.text!)"
        
    }
    
}

